// MARKHOR Voice Messenger — Content Script
// Runs on: messenger.com & facebook.com/messages
// Features: Auto-translate typing → TTS audio → Waveform UI → Send voice message

(function () {
  'use strict';

  // ── State ────────────────────────────────────────────────────────────────
  let currentTranslatedText = '';
  let isRecording = false;
  let currentAudioBlob = null;
  let currentAudioUrl = null;
  let translateDebounce = null;
  let currentAudio = null;
  let waveformBarsCount = 20;

  // ── Inject Toast UI ───────────────────────────────────────────────
  function injectUI() {
    if (document.getElementById('markhor-toast')) return;

    // Toast
    const toast = document.createElement('div');
    toast.id = 'markhor-toast';
    toast.textContent = '';
    document.body.appendChild(toast);
  }

  // ── Detect the active Messenger chat input ────────────────────────────────
  function getChatInput() {
    // Messenger uses contenteditable div
    const selectors = [
      'div[contenteditable="true"][role="textbox"]',
      'div[aria-label*="message" i][contenteditable="true"]',
      'div[data-lexical-editor="true"]',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }


  // ── Voice Button Click → Translate current input ──────────────────────────
  function onVoiceButtonClick() {
    const input = getChatInput();
    if (!input) {
      showToast('⚠️ Chat input nahi mili! Koi conversation open karo.');
      return;
    }
    const text = input.innerText.trim();
    if (!text) {
      showToast('Pehle kuch type karo!');
      return;
    }
    requestTranslation(text);
  }

  // ── Preview TTS using Web Speech API ─────────────────────────────────────
  function onPreviewSpeak() {
    if (!currentTranslatedText) return;
    speakText(currentTranslatedText);
  }

  function speakText(text) {
    if (!window.speechSynthesis) {
      showToast('❌ Browser TTS support nahi hai!');
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = 0.95;
    utterance.pitch = 1.0;

    // Pick best voice
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find(v =>
      v.lang === 'en-US' && (v.name.includes('Google') || v.name.includes('Microsoft'))
    ) || voices.find(v => v.lang.startsWith('en'));
    if (preferred) utterance.voice = preferred;

    window.speechSynthesis.speak(utterance);
    showToast('🔊 Preview chal raha hai...');
  }

  // ── Record TTS to AudioBlob via MediaRecorder ─────────────────────────────
  async function recordTTSToBlob(text) {
    return new Promise((resolve, reject) => {
      // Create an AudioContext to capture speech output
      // We use a workaround: record the system audio stream from oscillator + speech
      // Best approach: use Web Audio API to synthesize and capture

      if (!window.speechSynthesis) {
        reject(new Error('No TTS'));
        return;
      }

      // Create offline audio context to render speech
      // Since Web Speech API doesn't give us an audio stream directly,
      // we use a trick: route through AudioContext destination stream capture
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      const ctx = new AudioContext();
      const dest = ctx.createMediaStreamDestination();

      // We'll use MediaRecorder on this stream
      const mediaRecorder = new MediaRecorder(dest.stream, { mimeType: 'audio/webm;codecs=opus' });
      const chunks = [];

      mediaRecorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        resolve(blob);
      };

      // Speak using utterance
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      utterance.rate = 0.95;

      const voices = window.speechSynthesis.getVoices();
      const preferred = voices.find(v => v.lang === 'en-US' && v.name.includes('Google'))
        || voices.find(v => v.lang.startsWith('en'));
      if (preferred) utterance.voice = preferred;

      utterance.onstart = () => mediaRecorder.start();
      utterance.onend = () => {
        setTimeout(() => mediaRecorder.stop(), 300);
        ctx.close();
      };
      utterance.onerror = (e) => reject(e);

      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
    });
  }

  // ── Main: Send Voice Message ──────────────────────────────────────────────
  async function onSendVoice() {
    if (!currentTranslatedText) {
      showToast('⚠️ Pehle kuch type karo!');
      return;
    }

    showToast('Voice generate ho rahi hai...');

    try {
      const blob = await generateAudioBlob(currentTranslatedText);
      currentAudioBlob = blob;
      currentAudioUrl = URL.createObjectURL(blob);

      // Inject waveform widget into chat
      injectWaveformIntoChat(currentAudioUrl, currentTranslatedText);

      // Attempt to send via file input
      await attachAudioToMessenger(blob);

      hideTranslateBar();
      showToast('✅ Voice message tayar! File attach ki gayi.');

    } catch (err) {
      console.error('[MARKHOR]', err);
      // Fallback: inject local playable waveform
      showToast('💡 Direct bheja nahi — player inject kiya gaya!');
      if (currentAudioUrl) {
        injectWaveformIntoChat(currentAudioUrl, currentTranslatedText);
      }
    }
  }

  // ── Generate Audio using Web Speech API + MediaRecorder ──────────────────
  async function generateAudioBlob(text) {
    // Strategy 1: Try getUserMedia loopback (works if permission granted)
    // Strategy 2: Fallback to Web Audio API oscillator synthesis
    // For TTS→blob we use a smart workaround with silent audio context routing

    return new Promise((resolve, reject) => {
      // Use SpeechSynthesis and capture via AudioContext
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      utterance.rate = 0.9;

      const voices = window.speechSynthesis.getVoices();
      const preferred = voices.find(v => v.lang === 'en-US' && (v.name.includes('Google') || v.name.includes('Zira') || v.name.includes('David')))
        || voices.find(v => v.lang.startsWith('en'));
      if (preferred) utterance.voice = preferred;

      // Duration estimate: ~150ms per word
      const words = text.split(' ').length;
      const estimatedMs = Math.max(2000, words * 400);

      // Create AudioContext with destination stream
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      const audioCtx = new AudioCtx({ sampleRate: 16000 });
      const destination = audioCtx.createMediaStreamDestination();

      // Create silent oscillator (keeps stream alive)
      const osc = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      gainNode.gain.value = 0; // silent
      osc.connect(gainNode);
      gainNode.connect(destination);
      osc.start();

      // MediaRecorder on the stream
      let mimeType = 'audio/webm';
      if (!MediaRecorder.isTypeSupported('audio/webm')) {
        mimeType = 'audio/ogg';
      }

      const recorder = new MediaRecorder(destination.stream, { mimeType });
      const chunks = [];
      recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
      recorder.onstop = () => {
        osc.stop();
        audioCtx.close();
        const blob = new Blob(chunks, { type: mimeType });
        resolve(blob);
      };

      utterance.onstart = () => recorder.start();
      utterance.onend = () => {
        setTimeout(() => recorder.stop(), 500);
      };
      utterance.onerror = (e) => {
        recorder.stop();
        reject(e);
      };

      // Fallback timeout
      setTimeout(() => {
        if (recorder.state === 'recording') recorder.stop();
      }, estimatedMs + 2000);

      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
    });
  }

  // ── Attach audio to Messenger file input ──────────────────────────────────
  async function attachAudioToMessenger(blob) {
    // 1. Find ANY file input
    let fileInput = document.querySelector('input[type="file"]');
    
    if (!fileInput) {
      // 2. Try to find and click the "Attach" button to trigger input creation
      const attachSelectors = [
        '[aria-label="Attach files"]', 
        '[aria-label="Attach a file"]',
        '[aria-label="Attach"]',
        '[data-testid="attach-button"]',
        'div[role="button"] svg path[d*="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.66 1.34 3 3 3s3-1.34 3-3V5c0-2.21-1.79-4-4-4S8 2.79 8 5v12.5c0 3.31 2.69 6 6 6s6-2.69 6-6V6h-1.5z"]' // Paperclip icon path
      ];
      
      for (const sel of attachSelectors) {
        const btn = document.querySelector(sel)?.closest('[role="button"]') || document.querySelector(sel);
        if (btn) {
          btn.click();
          await sleep(600);
          fileInput = document.querySelector('input[type="file"]');
          if (fileInput) break;
        }
      }
    }

    if (!fileInput) {
      // Final attempt: look for ANY icon that might be an attachment
      const allButtons = document.querySelectorAll('div[role="button"][aria-label]');
      for (const b of allButtons) {
        if (b.ariaLabel.toLowerCase().includes('attach') || b.ariaLabel.toLowerCase().includes('file')) {
          b.click();
          await sleep(600);
          fileInput = document.querySelector('input[type="file"]');
          if (fileInput) break;
        }
      }
    }

    if (!fileInput) throw new Error('File input not found');

    // Create File and DataTransfer
    const file = new File([blob], 'voice_message.mp3', { type: 'audio/mpeg' });
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    fileInput.files = dataTransfer.files;

    // Trigger events
    fileInput.dispatchEvent(new Event('change', { bubbles: true }));
    
    // Also try to drop it on the main input field as a fallback
    const chatInput = getChatInput();
    if (chatInput) {
      const dropEvent = new DragEvent('drop', {
        bubbles: true,
        cancelable: true,
        dataTransfer: dataTransfer
      });
      chatInput.dispatchEvent(dropEvent);
    }

    await sleep(1500); // Wait for upload

    // 3. Click Send
    const sendSelectors = [
      '[aria-label="Send"]',
      '[aria-label="Press Enter to send"]',
      '[data-testid="MessengerEntTarget_SendMessage"]',
      'div[role="button"] svg path[d*="M16.635 20.25ef"]', // Send icon path
      'button[type="submit"]'
    ];

    for (const sel of sendSelectors) {
      const btn = document.querySelector(sel)?.closest('[role="button"]') || document.querySelector(sel);
      if (btn) {
        btn.click();
        return;
      }
    }
    
    // Fallback: Press Enter
    if (chatInput) {
      chatInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    }
  }

  // ── Inject Waveform Widget into Chat ──────────────────────────────────────
  function injectWaveformIntoChat(audioUrl, text) {
    const chatContainer = findChatScrollContainer();

    if (!chatContainer) {
      // Fallback: fixed bottom overlay
      injectFloatingPlayer(audioUrl, text);
      return;
    }

    const wrap = document.createElement('div');
    wrap.className = 'markhor-waveform-wrap';
    wrap.setAttribute('data-markhor-audio', audioUrl);

    const bars = Array.from({ length: waveformBarsCount }, (_, i) => {
      // Natural voice waveform height pattern
      const heights = [8, 14, 20, 28, 24, 16, 30, 22, 18, 26, 12, 28, 20, 16, 24, 30, 18, 14, 22, 10];
      return `<div class="bar static" style="height:${heights[i]}px"></div>`;
    }).join('');

    wrap.innerHTML = `
      <button class="markhor-play-btn" title="Play voice message">
        <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
      </button>
      <div class="markhor-waveform" id="mwf-${Date.now()}">
        ${bars}
      </div>
      <span class="markhor-duration">0:00</span>
    `;

    chatContainer.appendChild(wrap);
    chatContainer.scrollTop = chatContainer.scrollHeight;

    // Set up playback
    setupWaveformPlayback(wrap, audioUrl);
  }

  function findChatScrollContainer() {
    const selectors = [
      '[role="main"] [aria-label*="Message"] [class*="scrollable"]',
      '[data-testid="message-list"]',
      '[role="main"] > div > div > div',
      '.x78zum5.xdt5ytf',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    // Try to find scrollable area in the main content
    const main = document.querySelector('[role="main"]');
    if (main) {
      const divs = main.querySelectorAll('div');
      for (const d of divs) {
        if (d.scrollHeight > d.clientHeight + 100) return d;
      }
    }
    return null;
  }

  function injectFloatingPlayer(audioUrl, text) {
    let player = document.getElementById('markhor-floating-player');
    if (player) player.remove();

    player = document.createElement('div');
    player.id = 'markhor-floating-player';
    player.style.cssText = `
      position:fixed;bottom:160px;right:16px;z-index:99999;
      background:rgba(10,20,40,0.95);border:1px solid rgba(0,132,255,0.4);
      border-radius:16px;padding:12px;backdrop-filter:blur(12px);
      box-shadow:0 8px 32px rgba(0,0,0,0.5);
    `;

    const bars = Array.from({ length: 20 }, (_, i) => {
      const heights = [8, 14, 20, 28, 24, 16, 30, 22, 18, 26, 12, 28, 20, 16, 24, 30, 18, 14, 22, 10];
      return `<div class="bar static" style="height:${heights[i]}px"></div>`;
    }).join('');

    player.innerHTML = `
      <div style="font-family:'Segoe UI',sans-serif;font-size:10px;color:#0084ff;font-weight:700;margin-bottom:8px;letter-spacing:1px;">🎙️ MARKHOR VOICE</div>
      <div class="markhor-waveform-wrap" style="max-width:240px;margin:0;">
        <button class="markhor-play-btn">
          <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
        </button>
        <div class="markhor-waveform">${bars}</div>
        <span class="markhor-duration">0:00</span>
      </div>
      <div style="font-family:'Segoe UI',sans-serif;font-size:11px;color:#8899bb;margin-top:8px;font-style:italic;">"${text.substring(0, 60)}${text.length > 60 ? '...' : ''}"</div>
      <button onclick="this.parentElement.remove()" style="position:absolute;top:8px;right:8px;background:none;border:none;color:#8899bb;cursor:pointer;font-size:14px;">✕</button>
    `;

    document.body.appendChild(player);
    setupWaveformPlayback(player.querySelector('.markhor-waveform-wrap'), audioUrl);
  }

  // ── Waveform Playback Logic ───────────────────────────────────────────────
  function setupWaveformPlayback(wrap, audioUrl) {
    const playBtn = wrap.querySelector('.markhor-play-btn');
    const waveform = wrap.querySelector('.markhor-waveform');
    const durationEl = wrap.querySelector('.markhor-duration');

    const audio = new Audio(audioUrl);
    let playing = false;

    // Get duration once metadata loaded
    audio.addEventListener('loadedmetadata', () => {
      const d = Math.round(audio.duration);
      durationEl.textContent = `0:${d.toString().padStart(2, '0')}`;
    });

    audio.addEventListener('timeupdate', () => {
      const remaining = Math.round(audio.duration - audio.currentTime);
      if (!isNaN(remaining)) {
        durationEl.textContent = `0:${remaining.toString().padStart(2, '0')}`;
      }
    });

    audio.addEventListener('ended', () => {
      playing = false;
      waveform.classList.remove('playing');
      playBtn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>`;
      durationEl.textContent = `0:${Math.round(audio.duration).toString().padStart(2, '0')}`;
    });

    playBtn.addEventListener('click', () => {
      if (playing) {
        audio.pause();
        playing = false;
        waveform.classList.remove('playing');
        playBtn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>`;
      } else {
        // Stop any other playing audio
        if (currentAudio && currentAudio !== audio) {
          currentAudio.pause();
          document.querySelectorAll('.markhor-waveform.playing').forEach(el => {
            el.classList.remove('playing');
            const btn = el.closest('.markhor-waveform-wrap')?.querySelector('.markhor-play-btn');
            if (btn) btn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>`;
          });
        }
        audio.play();
        playing = true;
        currentAudio = audio;
        waveform.classList.add('playing');
        playBtn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>`;
      }
    });
  }

  // ── Toast notification ────────────────────────────────────────────────────
  function showToast(msg) {
    const toast = document.getElementById('markhor-toast');
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function getProDeviceID() {
    try {
      const specs = [
        navigator.platform || "Win32",
        String(navigator.hardwareConcurrency || 4),
        Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
        navigator.language || "en"
      ].join("|");
      
      let hash = 2166136261;
      for (let i = 0; i < specs.length; i++) {
        hash ^= specs.charCodeAt(i);
        hash = (hash * 16777619) >>> 0;
      }
      
      return "MARKHOR_" + hash.toString(36).toUpperCase().padStart(7, "0");
    } catch (e) {
      return "MARKHOR_FALLBACK";
    }
  }

  // ── Block Screen Overlay ──
  function showBlockedOverlay(deviceId) {
    if (document.getElementById('markhor-blocked-overlay')) return;
    
    if (!deviceId) {
      chrome.storage.local.get(["deviceId"], (data) => {
        const idToUse = data.deviceId || "LOADING...";
        renderOverlay(idToUse);
      });
    } else {
      renderOverlay(deviceId);
    }

    function renderOverlay(id) {
      if (document.getElementById('markhor-blocked-overlay')) {
        const idBox = document.getElementById('markhor-overlay-device-id');
        if (idBox) idBox.textContent = id;
        return;
      }
      const overlay = document.createElement("div");
      overlay.id = 'markhor-blocked-overlay';
      overlay.style.cssText = `
        position: fixed; inset: 0; background: #0a0a0a; color: #ff3131;
        z-index: 2147483647; display: flex; flex-direction: column;
        justify-content: center; align-items: center; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        text-align: center; padding: 20px;
      `;
      overlay.innerHTML = `
        <h1 style="font-size: 56px; font-weight: 900; letter-spacing: 5px; margin-bottom: 20px; color: #ff3131; text-transform: uppercase;">ACCESS DENIED</h1>
        <p style="font-size: 18px; color: #bbb; max-width: 600px; line-height: 1.6; margin-bottom: 30px;">Your extension access has been restricted by the administrator. Please contact your administrator to authorize this device.</p>
        <div style="padding: 15px 30px; border: 1px solid #ff3131; background: rgba(255,49,49,0.05); border-radius: 12px; font-weight: bold; color: white; font-size: 16px; text-transform: uppercase; letter-spacing: 1px; box-shadow: 0 0 20px rgba(255,49,49,0.2); margin-bottom: 20px;">
          Device ID: <span id="markhor-overlay-device-id" style="color: #ff3131; font-family: monospace;">${id}</span>
        </div>
        <a href="https://wa.me/923194949103" target="_blank" style="display: flex; align-items: center; justify-content: center; gap: 8px; background: #ff3131; color: #000; text-decoration: none; padding: 15px 25px; border-radius: 8px; font-weight: 800; font-size: 15px; box-shadow: 0 4px 15px rgba(255, 49, 49, 0.4); transition: 0.3s;">
          Send ID on WhatsApp
        </a>
      `;
      document.documentElement.appendChild(overlay);
    }
  }

  // ── Init ──────────────────────────────────────────────────────────────────
  function init() {
    // 1. Initial State Check (Local Sync)
    chrome.storage.local.get(["isBlocked"], (data) => {
      if (data.isBlocked) {
        showBlockedOverlay();
      }
    });

    // 2. Storage Changed Listener (Live Sync)
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.isBlocked) {
        if (changes.isBlocked.newValue === true) {
          showBlockedOverlay();
        } else {
          const blockedOverlay = document.getElementById('markhor-blocked-overlay');
          if (blockedOverlay) blockedOverlay.remove();
          location.reload();
        }
      }
    });

    // Wait for messenger to fully load
    const checkInterval = setInterval(() => {
      if (document.body) {
        injectUI();
        clearInterval(checkInterval);
        
        // Generate and save stable Device ID
        getProDeviceID().then(proID => {
          chrome.storage.local.get(['deviceId'], (res) => {
            if (res.deviceId !== proID) {
              chrome.storage.local.set({ deviceId: proID }, () => {
                chrome.runtime.sendMessage({ action: 'FORCE_LICENSE_CHECK' });
              });
            }
          });
        });
      }
    }, 500);
  }

  // ── Message Listener from Popup ──────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'SEND_TEXT') {
      const input = getChatInput();
      if (!input) {
        showToast('❌ Messenger input nahi mili!');
        sendResponse({ success: false });
        return;
      }

      // Robust text injection for Lexical/DraftJS
      input.focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
      document.execCommand('insertText', false, msg.text);
      
      input.dispatchEvent(new Event('input', { bubbles: true }));

      // Send after a small delay
      setTimeout(() => {
        const sendBtn = document.querySelector(
          '[aria-label="Send"], [aria-label="Press Enter to send"], [data-testid="MessengerEntTarget_SendMessage"], .x1i10hfl[role="button"][tabindex="0"] svg[viewBox*="0 0 24 24"]'
        )?.closest('[role="button"]') || document.querySelector('button[type="submit"]');
        
        if (sendBtn) {
          sendBtn.click();
          showToast('Text sent!');
          sendResponse({ success: true });
        } else {
          // Fallback: Press Enter key
          const enterEvent = new KeyboardEvent('keydown', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true,
            cancelable: true
          });
          input.dispatchEvent(enterEvent);
          showToast('✅ Text sent (Enter)!');
          sendResponse({ success: true });
        }
      }, 500);
      return true;
    }

    if (msg.action === 'ATTACH_VOICE') {
      onAttachVoiceManual(msg.text, msg.dataUrl).then(() => {
        sendResponse({ success: true });
      }).catch(err => {
        console.error(err);
        sendResponse({ success: false, error: err.message });
      });
      return true;
    }
  });

  async function onAttachVoiceManual(text, dataUrl) {
    showToast('🎙️ Voice attach ho rahi hai...');
    
    // Convert dataUrl to blob
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    
    currentAudioUrl = URL.createObjectURL(blob);
    
    // Inject waveform widget into chat
    injectWaveformIntoChat(currentAudioUrl, text);

    // Attempt to send via file input
    try {
      await attachAudioToMessenger(blob);
      showToast('Voice message sent!');
    } catch (e) {
      showToast('💡 Player inject kiya (Auto-attach failed)');
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
