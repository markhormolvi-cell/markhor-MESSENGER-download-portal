/**
 * MARKHOR Voice Messenger — Popup Script
 * 
 * Lock screen logic:
 * 1. Show instant UI from cached storage (no flicker)
 * 2. Trigger background sync immediately
 * 3. React to sync result and update UI
 * 4. Listen to storage changes for real-time updates
 * 5. Keep voice recording, typing debounce translate and speak logic intact!
 */

"use strict";

// ─────────────────────────────────────────────────────────────────────────────
// DOM ELEMENT REFERENCES
// Centralize all DOM queries here for performance and clarity
// ─────────────────────────────────────────────────────────────────────────────
const DOM = {
  lockScreen:      () => document.getElementById("lockScreen"),
  mainContent:     () => document.getElementById("mainContent"),
  lockDeviceId:    () => document.getElementById("lockDeviceId"),
  customAlertOverlay: () => document.getElementById("customAlertOverlay"),
  customAlertMessage: () => document.getElementById("customAlertMessage"),
  customAlertClose:   () => document.getElementById("customAlertClose"),
  popupInput:      () => document.getElementById("popupInput"),
  btnSendVoice:    () => document.getElementById("btnSendVoice")
};

// ─────────────────────────────────────────────────────────────────────────────
// LOCK SCREEN MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────
function showLockScreen(deviceId) {
  const lockScreen   = DOM.lockScreen();
  const mainContent  = DOM.mainContent();
  const deviceIdEl   = DOM.lockDeviceId();
  
  if (!lockScreen) return;
  if (deviceIdEl && deviceId) {
    deviceIdEl.textContent = deviceId;
  }
  
  lockScreen.style.display  = "flex";
  if (mainContent) {
    mainContent.style.display = "none";
  }
}

function hideLockScreen() {
  const lockScreen  = DOM.lockScreen();
  const mainContent = DOM.mainContent();
  
  if (!lockScreen) return;
  lockScreen.style.display  = "none";
  if (mainContent) {
    mainContent.style.display = "block";
  }
}

function applyLockState(isBlocked, deviceId) {
  if (isBlocked) {
    showLockScreen(deviceId);
  } else {
    hideLockScreen();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// STORAGE HELPER
// ─────────────────────────────────────────────────────────────────────────────
function storageGet(keys) {
  return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}

// ── Custom Alert ────────────────────────────────────────────────────────────
function showCustomAlert(message) {
  const overlay = DOM.customAlertOverlay();
  const msgEl = DOM.customAlertMessage();
  if (overlay && msgEl) {
    msgEl.textContent = message;
    overlay.style.display = 'flex';
  }
}

// ── Translate text using Google Translate free API ──────────────────────────
async function translateText(text) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: 'TRANSLATE', text }, (res) => {
      if (chrome.runtime.lastError || !res || !res.success) {
        resolve({ translated: text, detectedLang: 'en' });
        return;
      }
      resolve(res);
    });
  });
}

// ── Speak text ──────────────────────────────────────────────────────────────
let isPopupPlaying = false;
function speakText(text) {
  if (!window.speechSynthesis) return;

  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'en-US';
  utterance.rate = 0.9;

  const voices = window.speechSynthesis.getVoices();
  const preferred = voices.find(v =>
    v.lang === 'en-US' && (v.name.includes('Google') || v.name.includes('Microsoft'))
  ) || voices.find(v => v.lang.startsWith('en'));
  if (preferred) utterance.voice = preferred;

  utterance.onstart = () => { isPopupPlaying = true; };
  utterance.onend = () => { isPopupPlaying = false; };
  window.speechSynthesis.speak(utterance);
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN INITIALIZATION
// ─────────────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  console.log("[MARKHOR Popup] DOMContentLoaded — initializing...");
  
  // ── Phase 1: Instant render from cached state ─────────────────────────
  const cachedData = await storageGet(["isBlocked", "deviceId", "hasSynced"]);
  console.log("[MARKHOR Popup] Cached state:", cachedData);
  
  if (cachedData.deviceId) {
    const deviceIdEl = DOM.lockDeviceId();
    if (deviceIdEl) deviceIdEl.textContent = cachedData.deviceId;
  }
  
  if (cachedData.hasSynced) {
    applyLockState(Boolean(cachedData.isBlocked), cachedData.deviceId);
  }
  
  // ── Phase 2: Request fresh sync from background ───────────────────────
  try {
    const syncResult = await new Promise((resolve) => {
      const timeout = setTimeout(() => resolve({ success: false, error: "Sync timeout" }), 20000);
      chrome.runtime.sendMessage({ action: "force_sync" }, (response) => {
        clearTimeout(timeout);
        if (chrome.runtime.lastError) {
          resolve({ success: false, error: chrome.runtime.lastError.message });
          return;
        }
        resolve(response || { success: false, error: "No response" });
      });
    });
    
    console.log("[MARKHOR Popup] Sync result:", syncResult);
    
    const freshData = await storageGet(["isBlocked", "deviceId"]);
    console.log("[MARKHOR Popup] Fresh storage state:", freshData);
    
    applyLockState(Boolean(freshData.isBlocked), freshData.deviceId);
  } catch (err) {
    console.error("[MARKHOR Popup] Sync error:", err);
    const fallbackData = await storageGet(["isBlocked", "deviceId"]);
    applyLockState(Boolean(fallbackData.isBlocked), fallbackData.deviceId);
  }
  
  // ── Phase 4: Real-time storage listener ──────────────────────────────
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if ("isBlocked" in changes) {
      const newIsBlocked = Boolean(changes.isBlocked.newValue);
      const newDeviceId  = changes.deviceId?.newValue;
      storageGet(["deviceId"]).then(data => {
        applyLockState(newIsBlocked, newDeviceId || data.deviceId);
      });
    }
  });
  
  // ── Phase 5: Initialize rest of popup functionality ───────────────────
  initPopupFeatures();
});

// ─────────────────────────────────────────────────────────────────────────────
// POPUP FEATURES (Translation, Typing Debate Translation, Speak & Send Voice)
// ─────────────────────────────────────────────────────────────────────────────
function initPopupFeatures() {
  console.log("[MARKHOR Popup] Initializing popup features...");
  
  let currentTranslation = '';
  
  // Alert close handler
  const closeAlertBtn = DOM.customAlertClose();
  if (closeAlertBtn) {
    closeAlertBtn.addEventListener('click', () => {
      const overlay = DOM.customAlertOverlay();
      if (overlay) overlay.style.display = 'none';
    });
  }

  // ── Auto-translate and Auto-speak while typing ──
  let debounce;
  const inputEl = DOM.popupInput();
  if (inputEl) {
    inputEl.addEventListener('input', () => {
      clearTimeout(debounce);
      debounce = setTimeout(async () => {
        const text = inputEl.value.trim();
        if (!text || text.length < 3) {
          currentTranslation = '';
          return;
        }

        const res = await translateText(text);
        currentTranslation = res.translated;
        speakText(currentTranslation);
      }, 800);
    });
  }

  // ── Send Voice (VOICE) ──
  const sendVoiceBtn = DOM.btnSendVoice();
  if (sendVoiceBtn) {
    sendVoiceBtn.addEventListener('click', async () => {
      let textToSend = currentTranslation;
      
      if (!textToSend) {
        const inputVal = inputEl ? inputEl.value.trim() : '';
        if (!inputVal) return;
        const res = await translateText(inputVal);
        textToSend = res.translated;
      }

      const btn = DOM.btnSendVoice();
      const originalText = btn.innerHTML;
      btn.innerHTML = '<span class="spinner"></span> Processing...';
      btn.disabled = true;

      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs[0] || (!tabs[0].url.includes('messenger.com') && !tabs[0].url.includes('facebook.com/messages'))) {
          showCustomAlert('Ye button sirf Messenger chat par kaam karta hai!');
          btn.innerHTML = originalText;
          btn.disabled = false;
          return;
        }

        // 1. Generate Voice in background
        chrome.runtime.sendMessage({ action: 'GENERATE_VOICE_BLOB', text: textToSend }, (res) => {
          if (chrome.runtime.lastError || !res || !res.success) {
            showCustomAlert('Voice generation failed!');
            btn.innerHTML = originalText;
            btn.disabled = false;
            return;
          }

          // 2. Send dataUrl to content script to attach
          chrome.tabs.sendMessage(tabs[0].id, { action: 'ATTACH_VOICE', text: textToSend, dataUrl: res.dataUrl }, (response) => {
            if (chrome.runtime.lastError) {
              showCustomAlert('Error: Messenger page ko REFRESH karein!');
            }
            window.close();
          });
        });
      });
    });
  }
}
