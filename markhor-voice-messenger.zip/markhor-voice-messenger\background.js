/**
 * MARKHOR Voice Messenger — Background Service Worker
 * Manifest V3 Compatible
 * 
 * Responsibilities:
 * 1. Generate and persist stable Device ID
 * 2. Run tracking/licensing sync with GAS backend (direct, preflight-safe)
 * 3. Propagate block/unblock state to all tabs via storage
 * 4. Handle periodic re-checks
 * 5. Meticulously maintain Translation & TTS Speech Synthesis engines!
 */

"use strict";

// ─────────────────────────────────────────────────────────────────────────────
// CONFIGURATION
// ─────────────────────────────────────────────────────────────────────────────
const CONFIG = {
  API_URL: "https://markhor-messengerrrrrrrrrrrrrrrrrrr.vercel.app/api/proxy",
  
  // IP lookup service (fallback chain)
  IP_SERVICES: [
    "https://api.ipify.org?format=json",       // Returns { ip: "..." }
    "https://api.my-ip.io/ip.json",             // Returns { ip: "..." }
  ],
  
  IP_GEO_SERVICE: "https://ip-api.com/json/",  // Returns full geo data
  
  // Sync intervals
  PERIODIC_SYNC_ALARM: "markhor_periodic_sync",
  PERIODIC_INTERVAL_MINUTES: 5,
  
  // Fetch timeout in milliseconds
  FETCH_TIMEOUT_MS: 15000,
};

// ─────────────────────────────────────────────────────────────────────────────
// DEVICE ID GENERATION
// Generates a stable fingerprint-based ID that survives browser restarts
// ─────────────────────────────────────────────────────────────────────────────
async function generateSmartDeviceId() {
  const specs = [
    navigator.platform || "Win32",
    String(navigator.hardwareConcurrency || 4),
    Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
    navigator.language || "en"
  ].join("|");
  
  // FNV-1a 32-bit hash — fast, low-collision
  let hash = 2166136261;
  for (let i = 0; i < specs.length; i++) {
    hash ^= specs.charCodeAt(i);
    hash = (hash * 16777619) >>> 0;
  }
  
  return "MARKHOR_" + hash.toString(36).toUpperCase().padStart(7, "0");
}

// ─────────────────────────────────────────────────────────────────────────────
// FETCH WITH TIMEOUT (AbortController)
// ─────────────────────────────────────────────────────────────────────────────
async function fetchWithTimeout(url, options = {}, timeoutMs = CONFIG.FETCH_TIMEOUT_MS) {
  const controller = new AbortController();
  const timeoutId  = setTimeout(() => controller.abort(), timeoutMs);
  
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    return response;
  } finally {
    clearTimeout(timeoutId);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// IP & GEO LOOKUP
// ─────────────────────────────────────────────────────────────────────────────
async function getIpAndLocation() {
  try {
    const res     = await fetchWithTimeout(CONFIG.IP_GEO_SERVICE, {}, 8000);
    const ipData  = await res.json();
    
    if (ipData.status === "success" || ipData.query) {
      return {
        ip:       ipData.query       || "Unknown",
        location: [ipData.city, ipData.country]
                    .filter(Boolean)
                    .join(", ")      || "Unknown"
      };
    }
  } catch (geoErr) {
    for (const service of CONFIG.IP_SERVICES) {
      try {
        const res    = await fetchWithTimeout(service, {}, 5000);
        const data   = await res.json();
        const ip     = data.ip || data.IPv4 || "Hidden";
        return { ip, location: "N/A" };
      } catch (ipErr) { }
    }
  }
  return { ip: "Hidden", location: "N/A" };
}

// ─────────────────────────────────────────────────────────────────────────────
// STORAGE HELPERS
// ─────────────────────────────────────────────────────────────────────────────
function storageGet(keys) {
  return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}

function storageSet(data) {
  return new Promise(resolve => chrome.storage.local.set(data, resolve));
}

// ─────────────────────────────────────────────────────────────────────────────
// BROADCAST STATE CHANGE TO TABS
// ─────────────────────────────────────────────────────────────────────────────
async function broadcastToAllTabs(message) {
  try {
    const tabs = await chrome.tabs.query({});
    const promises = tabs.map(tab => {
      if (!tab.id || tab.url?.startsWith("chrome://")) return Promise.resolve();
      return chrome.tabs.sendMessage(tab.id, message).catch(() => { });
    });
    await Promise.allSettled(promises);
  } catch (err) { }
}

// ─────────────────────────────────────────────────────────────────────────────
// CORE TRACKING ENGINE
// ─────────────────────────────────────────────────────────────────────────────
async function runUserTracking() {
  console.log("[MARKHOR] Starting user tracking sync...");
  
  const localData = await storageGet(["deviceId", "profileId"]);
  let deviceId  = localData.deviceId;
  let profileId = localData.profileId;
  
  if (!deviceId) {
    deviceId = await generateSmartDeviceId();
    console.log("[MARKHOR] Generated new Device ID:", deviceId);
  }
  
  if (!profileId) {
    profileId = "PROF-" + Math.random().toString(36).substring(2, 10).toUpperCase();
  }
  
  await storageSet({ deviceId, profileId });
  
  const { ip, location } = await getIpAndLocation();
  
  const payload = {
    action:         "track",
    deviceId:       deviceId,
    profileId:      profileId,
    ip:             ip,
    location:       location,
    pcDetails:      `${navigator.platform} | ${navigator.hardwareConcurrency || 1} Cores | ${navigator.language}`,
    browserDetails: navigator.userAgent.substring(0, 150),
  };
  
  console.log("[MARKHOR] Sending tracking payload for:", deviceId);
  
  let result;
  try {
    // redirect: "follow" is required because GAS redirects after auth
    // NO custom JSON header is sent to completely bypass preflight OPTIONS CORS block!
    const response = await fetchWithTimeout(
      CONFIG.API_URL,
      {
        method:   "POST",
        redirect: "follow",
        body: JSON.stringify(payload),
      },
      CONFIG.FETCH_TIMEOUT_MS
    );
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const text = await response.text();
    try {
      result = JSON.parse(text);
    } catch (jsonErr) {
      console.error("[MARKHOR] Non-JSON response from GAS:", text.substring(0, 200));
      throw new Error("Invalid JSON response from server");
    }
    
    console.log("[MARKHOR] Server response:", result);
  } catch (fetchErr) {
    console.warn("[MARKHOR] API call failed:", fetchErr.message);
    await storageSet({ lastSyncError: fetchErr.message, lastSyncAttempt: Date.now() });
    return { success: false, error: fetchErr.message };
  }
  
  if (!result || typeof result.isBlocked === "undefined") {
    console.error("[MARKHOR] Invalid response structure:", result);
    return { success: false, error: "Invalid server response structure" };
  }
  
  const prevData    = await storageGet(["isBlocked"]);
  const wasBlocked  = prevData.isBlocked;
  const nowBlocked  = Boolean(result.isBlocked);
  
  await storageSet({
    isBlocked:     nowBlocked,
    userStatus:    result.status        || (nowBlocked ? "Blocked" : "Active"),
    broadcast:     result.broadcast     || "",
    voiceUrl:      result.voiceUrl      || "",
    hasHeardVoice: result.hasHeardVoice ?? true,
    hasSynced:     true,
    lastSyncTime:  Date.now(),
    lastSyncError: null,
  });
  
  console.log(`[MARKHOR] Sync complete. isBlocked: ${nowBlocked} (was: ${wasBlocked})`);
  
  if (nowBlocked !== wasBlocked) {
    const message = nowBlocked
      ? { action: "FORCE_BLOCK" }
      : { action: "FORCE_UNBLOCK" };
    
    await broadcastToAllTabs(message);
    console.log(`[MARKHOR] State changed → broadcasting ${message.action} to all tabs`);
  }
  
  return { success: true, isBlocked: nowBlocked, status: result.status };
}

// ─────────────────────────────────────────────────────────────────────────────
// SERVICE WORKER LIFECYCLE
// ─────────────────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log("[MARKHOR] Extension installed/updated:", details.reason);
  await chrome.alarms.clear(CONFIG.PERIODIC_SYNC_ALARM);
  chrome.alarms.create(CONFIG.PERIODIC_SYNC_ALARM, {
    delayInMinutes:  1,
    periodInMinutes: CONFIG.PERIODIC_INTERVAL_MINUTES
  });
  await runUserTracking();
});

chrome.runtime.onStartup.addListener(async () => {
  console.log("[MARKHOR] Browser startup — running initial sync...");
  await runUserTracking();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === CONFIG.PERIODIC_SYNC_ALARM) {
    console.log("[MARKHOR] Periodic sync triggered");
    await runUserTracking();
  }
});

// ─── Google Translate (Free Endpoint) ─────────────────────────────────────
async function translateToEnglish(text) {
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(text)}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Translate API failed');
    const data = await res.json();
    const translated = data[0].map(seg => seg[0]).join('');
    const detectedLang = data[2];
    return { translated, detectedLang, original: text };
  } catch (e) {
    console.error('[MARKHOR] Translation error:', e);
    return { translated: text, detectedLang: 'en', original: text };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CORE MESSAGE RECEIVER
// ─────────────────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const action = message?.action;
  
  if (action === "force_sync" || action === "FORCE_LICENSE_CHECK") {
    runUserTracking()
      .then(result => sendResponse({ success: true, ...result }))
      .catch(err   => sendResponse({ success: false, error: err.message }));
    return true; 
  }
  
  if (action === "get_status" || action === "GET_LICENSE_STATUS") {
    storageGet(["isBlocked", "deviceId", "userStatus", "lastSyncTime"])
      .then(data => sendResponse({ success: true, ...data }))
      .catch(err  => sendResponse({ success: false, error: err.message }));
    return true;
  }
  
  if (action === 'TRANSLATE') {
    translateToEnglish(message.text).then(result => {
      sendResponse({ success: true, ...result });
    }).catch(e => {
      sendResponse({ success: false, error: e.message });
    });
    return true;
  }

  if (action === 'GET_SETTINGS') {
    chrome.storage.local.get(['geminiApiKey', 'autoSend', 'voiceEnabled', 'voiceName'], data => {
      sendResponse(data);
    });
    return true;
  }

  if (action === 'OPEN_MESSENGER') {
    chrome.tabs.query({ url: ['*://www.messenger.com/*', '*://www.facebook.com/messages/*'] }, tabs => {
      if (tabs.length > 0) {
        chrome.tabs.update(tabs[0].id, { active: true });
        sendResponse({ tabId: tabs[0].id });
      } else {
        chrome.tabs.create({ url: 'https://www.messenger.com' }, tab => {
          sendResponse({ tabId: tab.id });
        });
      }
    });
    return true;
  }

  if (action === 'GENERATE_VOICE_BLOB') {
    const text = message.text;
    const maxLength = 180;
    const chunks = [];
    let currentChunk = '';
    const words = text.split(' ');
    
    for (const word of words) {
      if (currentChunk.length + word.length + 1 > maxLength) {
        if (currentChunk) chunks.push(currentChunk);
        currentChunk = word;
      } else {
        currentChunk += (currentChunk ? ' ' : '') + word;
      }
    }
    if (currentChunk) chunks.push(currentChunk);

    Promise.all(chunks.map(chunk => {
      const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(chunk)}&tl=en&client=tw-ob`;
      return fetch(url).then(r => {
        if (!r.ok) throw new Error('Fetch failed: ' + r.status);
        return r.blob();
      });
    }))
    .then(blobs => {
      const finalBlob = new Blob(blobs, { type: 'audio/mpeg' });
      const reader = new FileReader();
      reader.onloadend = () => sendResponse({ success: true, dataUrl: reader.result });
      reader.onerror = () => sendResponse({ success: false, error: 'File read error' });
      reader.readAsDataURL(finalBlob);
    })
    .catch(e => {
      console.error('[MARKHOR] TTS Fetch Error:', e);
      sendResponse({ success: false, error: e.message });
    });
    return true;
  }

  if (action === "voice_heard") {
    storageGet(["deviceId", "voiceUrl"]).then(async (data) => {
      try {
        await fetchWithTimeout(CONFIG.API_URL, {
          method: "POST",
          redirect: "follow",
          body: JSON.stringify({
            action: "voice_heard",
            deviceId: data.deviceId,
            voiceUrl: data.voiceUrl
          })
        });
        chrome.storage.local.set({ hasHeardVoice: true });
        sendResponse({ success: true });
      } catch (e) {
        sendResponse({ success: false });
      }
    });
    return true;
  }

  if (action === "ping") {
    sendResponse({ success: true, alive: true });
    return false;
  }
  
  return false;
});
